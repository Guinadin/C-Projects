﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Jober
{
    class Emprego
    {
        public string cargo { get; set; }
        public string salario { get; set; }
        public string horario { get; set; }
        public string beneficio { get; set; }
        public string direitos { get; set; }
        public object imagem { get; set; }
    }
}
