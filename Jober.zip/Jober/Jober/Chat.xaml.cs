﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Schema;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;


namespace Jober
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class Chat : ContentPage
    {

        public Chat()
        {
            InitializeComponent();

        }

        private async void ImageButton_Clicked(object sender, EventArgs e)
        {
            try
            {
                var gg = new Label
                {
                    Text = txt.Text,
                    TextColor = Color.Black,
                    HorizontalTextAlignment = TextAlignment.Start,
                    
                    FontSize = 18,
                    FontFamily = "{StaticResource SpecialFont}",
                    HorizontalOptions = LayoutOptions.StartAndExpand,
                    Margin = 10
                };
                Frame frame = new Frame
                {
                    BackgroundColor = Color.LightGreen,
                    BorderColor = Color.Gray,
                    CornerRadius = 10,
                    Padding = 0,
                    HasShadow = true,
                    HorizontalOptions = LayoutOptions.StartAndExpand,
                    Margin = 0,
                    Content = gg
                };

                Tela.Children.Add(frame);
                txt.Text = "";

                if (gg.Text == "Bom dia")
                {
                    Frame frame2 = new Frame
                    {
                        BackgroundColor = Color.LightGray,
                        BorderColor = Color.Gray,
                        CornerRadius = 10,
                        Padding = 0,
                        HasShadow = true,
                        HorizontalOptions = LayoutOptions.EndAndExpand,
                        Margin = 0,
                        Content = new Label
                        {

                            Text = "Alguma dúvida em releção a Vaga ?",
                            TextColor = Color.Black,
                            HorizontalTextAlignment = TextAlignment.Start,
                            
                            FontSize = 18,
                            FontFamily = "{StaticResource SpecialFont}",
                            HorizontalOptions = LayoutOptions.EndAndExpand,
                            Margin = 10
                        }

                    };
                    Tela.Children.Add(frame2);
                }

                if (gg.Text == "No momento não")
                {
                    Frame frame3 = new Frame
                    {
                        BackgroundColor = Color.LightGray,
                        BorderColor = Color.Gray,
                        CornerRadius = 10,
                        Padding = 0,
                        HasShadow = true,
                        HorizontalOptions = LayoutOptions.EndAndExpand,
                        Margin = 0,
                        Content = new Label
                        {

                            Text = "Então podemos marcar uma entrevista que tal ?",
                            TextColor = Color.Black,
                            HorizontalTextAlignment = TextAlignment.Start,

                            FontSize = 18,
                            FontFamily = "{StaticResource SpecialFont}",
                            HorizontalOptions = LayoutOptions.EndAndExpand,
                            Margin = 10
                        }

                    };
                    Tela.Children.Add(frame3);
                }

                if (gg.Text == "Claro podemos sim")
                {
                    Frame frame4 = new Frame
                    {
                        BackgroundColor = Color.LightGray,
                        BorderColor = Color.Gray,
                        CornerRadius = 10,
                        Padding = 0,
                        HasShadow = true,
                        HorizontalOptions = LayoutOptions.EndAndExpand,
                        Margin = 0,
                        Content = new Label
                        {

                            Text = "Sera aqui na empresa mesmo as 8h na Quarta",
                            TextColor = Color.Black,
                            HorizontalTextAlignment = TextAlignment.Start,

                            FontSize = 18,
                            FontFamily = "{StaticResource SpecialFont}",
                            HorizontalOptions = LayoutOptions.EndAndExpand,
                            Margin = 10
                        }

                    };
                    Tela.Children.Add(frame4);


                }

                if (gg.Text == "Perfeito")
                {
                    Frame frame6 = new Frame
                    {
                        BackgroundColor = Color.LightGray,
                        BorderColor = Color.Gray,
                        CornerRadius = 10,
                        Padding = 0,
                        HasShadow = true,
                        HorizontalOptions = LayoutOptions.EndAndExpand,
                        Margin = 0,
                        Content = new Label
                        {

                            Text = "O resto das informações te mando no e-mail",
                            TextColor = Color.Black,
                            HorizontalTextAlignment = TextAlignment.Start,

                            FontSize = 18,
                            FontFamily = "{StaticResource SpecialFont}",
                            HorizontalOptions = LayoutOptions.EndAndExpand,
                            Margin = 10
                        }

                    };
                    Tela.Children.Add(frame6);
                }

                if (gg.Text == "Ate quarta então")
                {
                    Frame frame7 = new Frame
                    {
                        BackgroundColor = Color.LightGray,
                        BorderColor = Color.Gray,
                        CornerRadius = 10,
                        Padding = 0,
                        HasShadow = true,
                        HorizontalOptions = LayoutOptions.EndAndExpand,
                        Margin = 0,
                        Content = new Label
                        {

                            Text = "até 👍",
                            TextColor = Color.Black,
                            HorizontalTextAlignment = TextAlignment.Start,

                            FontSize = 18,
                            FontFamily = "{StaticResource SpecialFont}",
                            HorizontalOptions = LayoutOptions.EndAndExpand,
                            Margin = 10
                        }

                    };
                    Tela.Children.Add(frame7);
                }
            }
            

            catch(Exception x)
            {
                await DisplayAlert("opa algo deu errado", x.Message, "OK");
                
            }

        }

        
    }
}