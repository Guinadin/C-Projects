﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using Jober.View;

namespace Jober
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class Detail : ContentPage
    {
        

        public Detail()
        {
            InitializeComponent();
            
        }

        

        private void btnRecusar_Clicked(object sender, EventArgs e)
        {
            img.Source = "microsoft";
            Cargo.Text = "DBA SQL-Server";
            Salario.Text = "R$4.000,00";
            Horario.Text = "Segunda-Sabado 8h";
            Beneficio.Text = "Vale-Refeição + Vale-Alimentação";
            Direitos.Text = "30 dias de Ferias + 13°";
        }

        private async void btnAceitar_Clicked(object sender, EventArgs e)
        {
            try
            {
                await DisplayAlert("Parabens", "Seu curriculo foi enviado com sucesso", "OK");
                await Navigation.PushAsync(new Chat(), true);
            }

            catch (Exception x)
            {
                
                await DisplayAlert("opa algo deu errado", x.Message, "OK");

            }


        }
    }
}